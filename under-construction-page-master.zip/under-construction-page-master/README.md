# Animated Under Construction Page

Simple temporary page for web developers
